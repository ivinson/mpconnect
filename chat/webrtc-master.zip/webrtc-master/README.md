<h1>Video chat App with WebRTC</h1>

See more:
* [Live demo](https://scaledrone.github.io/webrtc/index.html)
* [Tutorial](https://www.scaledrone.com/blog/posts/webrtc-tutorial-simple-video-chat)
